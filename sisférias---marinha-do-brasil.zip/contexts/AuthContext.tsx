
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  users: User[];
  login: (email: string, pass: string) => Promise<boolean>;
  register: (name: string, email: string, pass: string, role?: 'admin' | 'user') => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
  getRegisteredUsers: () => User[];
  changeUserPassword: (email: string, newPass: string) => boolean;
  deleteUser: (userId: string) => void;
  toggleBlockUser: (userId: string, forceStatus?: boolean) => void;
  refreshUser: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);

  const getRegisteredUsers = (): User[] => {
    const saved = localStorage.getItem('vacation_users_db');
    return saved ? JSON.parse(saved) : [];
  };

  const refreshUser = () => {
    const saved = localStorage.getItem('vacation_user');
    const db = getRegisteredUsers();
    setUsers(db);
    if (saved) {
      const parsed = JSON.parse(saved);
      const current = db.find(u => u.id === parsed.id);
      if (current) {
        setUser(current);
        localStorage.setItem('vacation_user', JSON.stringify(current));
      }
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const login = async (email: string, pass: string): Promise<boolean> => {
    const db = getRegisteredUsers();
    const found = db.find(u => u.email === email && u.password === pass);
    if (found) {
      const { password, ...safeUser } = found;
      setUser(safeUser as User);
      localStorage.setItem('vacation_user', JSON.stringify(safeUser));
      return true;
    }
    return false;
  };

  const register = async (name: string, email: string, pass: string, role: 'admin' | 'user' = 'user'): Promise<boolean> => {
    const db = getRegisteredUsers();
    if (db.find(u => u.email === email)) return false;

    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      password: pass,
      role,
      isBlocked: false
    };

    const updated = [...db, newUser];
    localStorage.setItem('vacation_users_db', JSON.stringify(updated));
    setUsers(updated);
    return true;
  };

  const deleteUser = (userId: string) => {
    const db = getRegisteredUsers();
    const updated = db.filter(u => u.id !== userId);
    localStorage.setItem('vacation_users_db', JSON.stringify(updated));
    setUsers(updated);
    if (user?.id === userId) logout();
  };

  const toggleBlockUser = (userId: string, forceStatus?: boolean) => {
    const db = getRegisteredUsers();
    const idx = db.findIndex(u => u.id === userId);
    if (idx > -1) {
      const newStatus = forceStatus !== undefined ? forceStatus : !db[idx].isBlocked;
      
      // Evita atualizar se o status já for o pretendido
      if (db[idx].isBlocked === newStatus) return;

      db[idx].isBlocked = newStatus;
      localStorage.setItem('vacation_users_db', JSON.stringify(db));
      setUsers([...db]);
      
      if (user?.id === userId) {
        const updatedSelf = { ...user, isBlocked: newStatus };
        setUser(updatedSelf);
        localStorage.setItem('vacation_user', JSON.stringify(updatedSelf));
      }
    }
  };

  const changeUserPassword = (email: string, newPass: string): boolean => {
    const db = getRegisteredUsers();
    const idx = db.findIndex(u => u.email === email);
    if (idx === -1) return false;
    db[idx].password = newPass;
    localStorage.setItem('vacation_users_db', JSON.stringify(db));
    setUsers([...db]);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('vacation_user');
  };

  return (
    <AuthContext.Provider value={{ 
      user, users, login, register, logout, 
      isAuthenticated: !!user, 
      getRegisteredUsers,
      changeUserPassword,
      deleteUser,
      toggleBlockUser,
      refreshUser
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
