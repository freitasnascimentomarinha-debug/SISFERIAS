
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Employee, AuditLog, VacationParcel, SystemSettings, Notice } from '../types';
import { useAuth } from './AuthContext';

interface VacationContextType {
  employees: Employee[];
  auditLogs: AuditLog[];
  settings: SystemSettings;
  saveVacation: (data: Employee) => void;
  deleteVacation: (id: string) => void;
  getEmployeeByUserId: (userId: string) => Employee | undefined;
  addAuditLog: (log: Omit<AuditLog, 'id' | 'timestamp'>) => void;
  updateSettings: (newSettings: SystemSettings) => void;
}

const defaultSettings: SystemSettings = {
  institutionName: 'MARINHA DO BRASIL',
  totalManpower: 100,
  notices: [
    { id: '1', title: 'Bem-vindo ao Novo Sistema', content: 'Utilize o menu superior para navegar pelas funcionalidades de lançamento e consulta.', date: new Date().toISOString() }
  ]
};

const VacationContext = createContext<VacationContextType | undefined>(undefined);

export const VacationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [settings, setSettings] = useState<SystemSettings>(defaultSettings);
  const { user } = useAuth();

  useEffect(() => {
    const savedEmp = localStorage.getItem('vacation_employees');
    if (savedEmp) setEmployees(JSON.parse(savedEmp));

    const savedLogs = localStorage.getItem('vacation_audit_logs');
    if (savedLogs) setAuditLogs(JSON.parse(savedLogs));

    const savedSettings = localStorage.getItem('vacation_system_settings');
    if (savedSettings) setSettings(JSON.parse(savedSettings));
  }, []);

  const saveVacation = (data: Employee) => {
    setEmployees(prev => {
      const idx = prev.findIndex(e => e.id === data.id);
      let updated;
      if (idx > -1) {
        updated = [...prev];
        updated[idx] = data;
      } else {
        updated = [...prev, data];
      }
      localStorage.setItem('vacation_employees', JSON.stringify(updated));
      return updated;
    });
  };

  const deleteVacation = (id: string) => {
    setEmployees(prev => {
      const updated = prev.filter(e => e.id !== id);
      localStorage.setItem('vacation_employees', JSON.stringify(updated));
      return updated;
    });
  };

  const updateSettings = (newSettings: SystemSettings) => {
    setSettings(newSettings);
    localStorage.setItem('vacation_system_settings', JSON.stringify(newSettings));
  };

  const getEmployeeByUserId = (userId: string) => {
    return employees.find(e => e.userId === userId);
  };

  const addAuditLog = (logData: Omit<AuditLog, 'id' | 'timestamp'>) => {
    const newLog: AuditLog = {
      ...logData,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString()
    };
    setAuditLogs(prev => {
      const updated = [newLog, ...prev];
      localStorage.setItem('vacation_audit_logs', JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <VacationContext.Provider value={{ 
      employees, auditLogs, settings, saveVacation, deleteVacation, 
      getEmployeeByUserId, addAuditLog, updateSettings
    }}>
      {children}
    </VacationContext.Provider>
  );
};

export const useVacation = () => {
  const context = useContext(VacationContext);
  if (!context) throw new Error('useVacation must be used within VacationProvider');
  return context;
};
