
import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, Sun, LayoutDashboard, Calendar, FileText, ShieldAlert, PlusCircle, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

const Header: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();

  if (!user) return null;

  const navItems = [
    { label: 'Início', path: '/home', icon: <Home size={18} /> },
    { label: 'Painel', path: '/', icon: <LayoutDashboard size={18} /> },
    { label: 'Lançar Férias', path: '/vacation-form', icon: <PlusCircle size={18} /> },
    { label: 'Calendário', path: '/calendar', icon: <Calendar size={18} /> },
    { label: 'Impressão', path: '/print', icon: <FileText size={18} /> },
    { label: 'Segurança', path: '/security', icon: <ShieldAlert size={18} /> },
  ];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-50 no-print">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-100 rounded-lg text-orange-500">
            <Sun size={24} />
          </div>
          <div>
            <h1 className="font-bold text-lg text-slate-900 leading-tight">SISFÉRIAS</h1>
            <p className="text-[10px] font-bold text-orange-600 tracking-widest">MARINHA DO BRASIL</p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                location.pathname === item.path
                  ? 'bg-orange-500 text-white'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {item.icon}
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium text-slate-900">Olá, {user.name.split(' ')[0]}</p>
            <p className="text-xs text-slate-500 font-bold">{user.role === 'admin' ? 'Administrador' : 'Usuário'}</p>
          </div>
          <button
            type="button"
            onClick={logout}
            className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
            title="Sair"
          >
            <LogOut size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;