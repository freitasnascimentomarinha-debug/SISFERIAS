
import React from 'react';
import { MemoryRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { VacationProvider } from './contexts/VacationContext';
import Header from './components/Header';
import Dashboard from './pages/Dashboard';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import VacationForm from './pages/VacationForm';
import CalendarView from './pages/CalendarView';
import Security from './pages/Security';
import PrintVacation from './pages/PrintVacation';

const PrivateRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" />;
};

const AppContent: React.FC = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/home" element={<PrivateRoute><Home /></PrivateRoute>} />
        <Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
        <Route path="/vacation-form" element={<PrivateRoute><VacationForm /></PrivateRoute>} />
        <Route path="/vacation-form/:id" element={<PrivateRoute><VacationForm /></PrivateRoute>} />
        <Route path="/vacation-form/user/:userId" element={<PrivateRoute><VacationForm /></PrivateRoute>} />
        <Route path="/calendar" element={<PrivateRoute><CalendarView /></PrivateRoute>} />
        <Route path="/print" element={<PrivateRoute><PrintVacation /></PrivateRoute>} />
        <Route path="/print/:id" element={<PrivateRoute><PrintVacation /></PrivateRoute>} />
        <Route path="/security" element={<PrivateRoute><Security /></PrivateRoute>} />
        <Route path="*" element={<Navigate to="/home" />} />
      </Routes>
    </div>
  );
};

const App: React.FC = () => {
  return (
    <Router>
      <AuthProvider>
        <VacationProvider>
          <AppContent />
        </VacationProvider>
      </AuthProvider>
    </Router>
  );
};

export default App;
